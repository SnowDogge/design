onLeave: function(destination, direction){
    if(destination.index == 0 && (direction)){
        counting();
    }
},

function counting (){
    $('.counter').each(function() {
        var $this = $(this),
        countTo = $this.attr('data-end');
            
        $({countNum: $this.text()}).animate({
            countNum: countTo 
            },{
            duration: 3000,
            easing:'linear',
            step: function() {
            $this.text(Math.floor(this.countNum));
            },
            complete: function() {
            $this.text(this.countNum);
            }
        });  
    });
}